/* App层任务入口：只组织SWC调用，具体业务仍放在各SWC内部。 */

#include "App.h"
#include "Rte.h"
#include "Swc_AdcSampler.h"
#include "Swc_Command.h"
#include "Swc_Storage.h"
#include "Swc_IrHandler.h"
#include "Swc_LcdPresenter.h"
#include "Swc_SerialTx.h"

void App_Init(void)
{
    Rte_ClearSerialData(); /* 上电清掉串口残留字节，避免从半帧开始解析。 */

    /* 各SWC自己维护内部状态，App只统一调用初始化入口。 */
    Swc_AdcSampler_Init();
    Swc_Command_Init();
    Swc_Storage_Init();
    Swc_IrHandler_Init();
    Swc_LcdPresenter_Init();
    Swc_SerialTx_Init();
}

/* BSW任务：高频推进底层非阻塞状态机。 */
void App_BswTask(void)
{
    Rte_MainFunction();
}

/* 快速业务任务：处理命令、存储状态、红外和LCD显示请求。 */
void App_FastTask(void)
{
    Swc_Command_MainFunction();        /* 把串口字节翻译成业务请求 */
    Swc_Storage_MainFunction();        /* 消费保存/读取请求，推进EEPROM业务 */
    Swc_IrHandler_MainFunction();      /* 消费红外按键，更新LCD和LED */
    Swc_LcdPresenter_MainFunction();   /* 把显示请求送入LCD异步队列 */
}

/* ADC任务：周期调用采样SWC，SWC内部仍控制实际采样周期。 */
void App_AdcTask(void)
{
    Swc_AdcSampler_MainFunction(Rte_GetSystemTick()); /* 采样后发布ADC数据和显示请求 */
}

/* 串口发送任务：串口空闲时逐字节发送响应帧。 */
void App_SerialTask(void)
{
    Swc_SerialTx_MainFunction();       /* 串口空闲时逐字节发送响应 */
}
