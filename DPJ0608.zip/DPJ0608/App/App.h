/* App层对外暴露初始化入口和OS任务入口。 */

#ifndef APP_H
#define APP_H

#include "Config.h"

/* 轻量模块标识，便于后续调试或扩展Det。 */
#define APP_VENDOR_ID                 0u
#define APP_MODULE_ID                 1000u
#define APP_SW_MAJOR_VERSION          1u
#define APP_SW_MINOR_VERSION          0u
#define APP_SW_PATCH_VERSION          0u

void App_Init(void);

/* OS任务入口：由轻量OS按周期调用。 */
void App_BswTask(void);
void App_FastTask(void);
void App_AdcTask(void);
void App_SerialTask(void);

#endif
