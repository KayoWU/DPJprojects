#include "Swc_Command.h"
#include "Rte.h"

#define SWC_COMMAND_FRAME_HEAD     0xaau
#define SWC_COMMAND_FRAME_TAIL     0x55u
#define SWC_COMMAND_SAVE_ADC       0x01u
#define SWC_COMMAND_READ_ADC       0x02u

#define SWC_COMMAND_STATE_WAIT_HEAD 0u
#define SWC_COMMAND_STATE_WAIT_CMD  1u
#define SWC_COMMAND_STATE_WAIT_CHK  2u
#define SWC_COMMAND_STATE_WAIT_TAIL 3u

typedef uint8 Swc_CommandStateType;

typedef struct
{
    Swc_CommandStateType State;
    uint8 Cmd;
} Swc_CommandContextType;

static Swc_CommandContextType Swc_Command_Context;

void Swc_Command_Init(void)
{
    Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_HEAD;
    Swc_Command_Context.Cmd = 0u;
}

/* 校验规则很轻：CHK必须等于CMD按位取反。 */
static boolean Swc_Command_IsCheckOk(uint8 command, uint8 check)
{
    boolean isOk;

    if(check == (uint8)(command ^ 0xffu))
    {
        isOk = TRUE;
    }
    else
    {
        isOk = FALSE;
    }

    return isOk;
}

/* 校验通过后才发布业务请求，真正存储动作交给Storage SWC。 */
static void Swc_Command_Dispatch(uint8 command)
{
    if(command == SWC_COMMAND_SAVE_ADC)
    {
        Rte_RequestAdcSave();  /* 只发布请求，实际写EEPROM由Storage处理。 */
    }
    else if(command == SWC_COMMAND_READ_ADC)
    {
        Rte_RequestAdcRead();  /* Storage收到请求后再启动异步读。 */
    }
}

static void Swc_Command_HandleWaitHead(uint8 rxData)
{
    if(rxData == SWC_COMMAND_FRAME_HEAD)
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_CMD;
    }
}

static void Swc_Command_HandleWaitCmd(uint8 rxData)
{
    Swc_Command_Context.Cmd = rxData;
    Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_CHK;
}

static void Swc_Command_HandleWaitCheck(uint8 rxData)
{
    if(Swc_Command_IsCheckOk(Swc_Command_Context.Cmd, rxData) == TRUE)
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_TAIL;
    }
    else if(rxData == SWC_COMMAND_FRAME_HEAD)
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_CMD;
    }
    else
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_HEAD;
    }
}

static void Swc_Command_HandleWaitTail(uint8 rxData)
{
    if(rxData == SWC_COMMAND_FRAME_TAIL)
    {
        Swc_Command_Dispatch(Swc_Command_Context.Cmd);
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_HEAD;
    }
    else if(rxData == SWC_COMMAND_FRAME_HEAD)
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_CMD;
    }
    else
    {
        Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_HEAD;
    }
}

static void Swc_Command_HandleInvalidState(void)
{
    Swc_Command_Context.State = SWC_COMMAND_STATE_WAIT_HEAD;
}

/* 逐字节解析命令帧：AA CMD CHK 55，错位时自动重新找包头。 */
static void Swc_Command_ParseByte(uint8 rxData)
{
    switch(Swc_Command_Context.State)
    {
        case SWC_COMMAND_STATE_WAIT_HEAD:
            Swc_Command_HandleWaitHead(rxData);
            break;

        case SWC_COMMAND_STATE_WAIT_CMD:
            Swc_Command_HandleWaitCmd(rxData);
            break;

        case SWC_COMMAND_STATE_WAIT_CHK:
            Swc_Command_HandleWaitCheck(rxData);
            break;

        case SWC_COMMAND_STATE_WAIT_TAIL:
            Swc_Command_HandleWaitTail(rxData);
            break;

        default:
            Swc_Command_HandleInvalidState();
            break;
    }
}

/* 串口命令SWC：从接收缓冲逐字节取数据，拼出完整安全命令帧。 */
void Swc_Command_MainFunction(void)
{
    while(Rte_IsSerialRxReady() == TRUE)
    {
        Swc_Command_ParseByte(Rte_ReadSerialData());
    }
}
