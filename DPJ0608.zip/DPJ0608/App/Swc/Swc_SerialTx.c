#include "Swc_SerialTx.h"
#include "Rte.h"

#define SWC_SERIAL_TX_BUFFER_LENGTH 8u

#define SWC_SERIAL_FRAME_HEAD       0xaau
#define SWC_SERIAL_FRAME_TAIL       0x55u
#define SWC_SERIAL_RESPONSE_READ    0x82u

typedef struct
{
    uint8 Buffer[SWC_SERIAL_TX_BUFFER_LENGTH];
    uint8 Length;
    uint8 Index;
} Swc_SerialTxContextType;

static Swc_SerialTxContextType xdata Swc_SerialTx_Context;

void Swc_SerialTx_Init(void)
{
    Swc_SerialTx_Context.Length = 0u;
    Swc_SerialTx_Context.Index = 0u;
}

static void Swc_SerialTx_StartReadMessage(uint8 adcRaw, uint16 adcMv)
{
    uint8 i;
    uint8 mvHigh;
    uint8 mvLow;
    uint8 check;

    for(i = 0u; i < SWC_SERIAL_TX_BUFFER_LENGTH; i++)
    {
        Swc_SerialTx_Context.Buffer[i] = '\0';
    }

    mvHigh = (uint8)(adcMv >> 8);
    mvLow = (uint8)adcMv;
    check = (uint8)(SWC_SERIAL_RESPONSE_READ ^ adcRaw ^ mvHigh ^ mvLow);

    /* 读取响应帧：AA 82 ADC_RAW MV_H MV_L CHK 55。 */
    Swc_SerialTx_Context.Buffer[0] = SWC_SERIAL_FRAME_HEAD;
    Swc_SerialTx_Context.Buffer[1] = SWC_SERIAL_RESPONSE_READ;
    Swc_SerialTx_Context.Buffer[2] = adcRaw;
    Swc_SerialTx_Context.Buffer[3] = mvHigh;
    Swc_SerialTx_Context.Buffer[4] = mvLow;
    Swc_SerialTx_Context.Buffer[5] = check;
    Swc_SerialTx_Context.Buffer[6] = SWC_SERIAL_FRAME_TAIL;
    Swc_SerialTx_Context.Length = 7u;
    Swc_SerialTx_Context.Index = 0u;
}

/* 串口发送SWC：消费发送请求，空闲时逐字节发出。 */
void Swc_SerialTx_MainFunction(void)
{
    uint8 adcRaw;
    uint16 adcMv;

    if(Rte_ConsumeSerialReadMessage(&adcRaw, &adcMv) == TRUE)
    {
        /* 新的读回结果会覆盖旧发送缓存，从头开始发。 */
        Swc_SerialTx_StartReadMessage(adcRaw, adcMv);
    }

    if((Swc_SerialTx_Context.Index < Swc_SerialTx_Context.Length) && (Rte_IsSerialTxReady() == TRUE))
    {
        Rte_SendSerialByte(Swc_SerialTx_Context.Buffer[Swc_SerialTx_Context.Index]);
        Swc_SerialTx_Context.Index++;
    }
}
