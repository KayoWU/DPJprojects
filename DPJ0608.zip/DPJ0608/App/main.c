/* 程序入口：上电初始化一次，然后交给轻量OS轮询调度任务。 */

#include "EcuM.h"
#include "App.h"
#include "Os.h"

int main(void)
{
    EcuM_Init();          /* 上电后一次性初始化所有硬件和BSW模块 */
    App_Init();           /* 初始化各个SWC内部状态 */
    Os_Init();            /* 初始化任务下次运行时间 */
    while(1)
    {
        Os_MainFunction(); /* 按Timer Tick轮询调度Task */
    }
}
