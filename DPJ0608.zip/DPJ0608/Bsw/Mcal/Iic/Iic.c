#include "Iic.h"

sbit Iic_Sda = P2^0;
sbit Iic_Scl = P2^1;

#define IIC_STATE_IDLE        0u
#define IIC_STATE_DONE        1u
#define IIC_STATE_START_0     2u
#define IIC_STATE_START_1     3u
#define IIC_STATE_START_2     4u
#define IIC_STATE_STOP_0      5u
#define IIC_STATE_STOP_1      6u
#define IIC_STATE_STOP_2      7u
#define IIC_STATE_ACK         8u
#define IIC_STATE_WRITE_LOW   9u
#define IIC_STATE_WRITE_HIGH  10u
#define IIC_STATE_READ_LOW    11u
#define IIC_STATE_READ_HIGH   12u
#define IIC_STATE_NACK_LOW    13u
#define IIC_STATE_NACK_HIGH   14u

typedef uint8 Iic_StateType;

typedef struct
{
    Iic_StateType State;
    uint8 CurrentByte;
    uint8 ReadData;
    uint8 BitIndex;
    uint8 AckCount;
} Iic_ContextType;

static Iic_ContextType Iic_Context;

/* IIC总线初始化：SDA和SCL都拉高，表示总线空闲。 */
void Iic_Init(void)
{
    Iic_Sda = 1;
    _nop_();
    Iic_Scl = 1;
    _nop_();
    Iic_Context.State = IIC_STATE_IDLE;
}

/* 启动一个IIC小操作：起始、停止、等ACK、写1字节、读1字节。 */
Std_ReturnType Iic_StartOperation(uint8 operation, uint8 dataValue)
{
    Std_ReturnType result;

    if(Iic_IsBusy() == TRUE)
    {
        result = E_NOT_OK;
    }
    else
    {
        Iic_Context.CurrentByte = dataValue;
        Iic_Context.ReadData = 0u;
        Iic_Context.BitIndex = 0u;
        Iic_Context.AckCount = 0u;

        if(operation == IIC_OPERATION_START)
        {
            Iic_Context.State = IIC_STATE_START_0;
            result = E_OK;
        }
        else if(operation == IIC_OPERATION_STOP)
        {
            Iic_Context.State = IIC_STATE_STOP_0;
            result = E_OK;
        }
        else if(operation == IIC_OPERATION_WAIT_ACK)
        {
            Iic_Context.State = IIC_STATE_ACK;
            result = E_OK;
        }
        else if(operation == IIC_OPERATION_WRITE_BYTE)
        {
            Iic_Context.State = IIC_STATE_WRITE_LOW;
            result = E_OK;
        }
        else if(operation == IIC_OPERATION_READ_BYTE)
        {
            Iic_Context.State = IIC_STATE_READ_LOW;
            result = E_OK;
        }
        else if(operation == IIC_OPERATION_SEND_NACK)
        {
            Iic_Context.State = IIC_STATE_NACK_LOW;
            result = E_OK;
        }
        else
        {
            Iic_Context.State = IIC_STATE_IDLE;
            result = E_NOT_OK;
        }
    }

    return result;
}

static void Iic_HandleStart0(void)
{
    Iic_Sda = 1;
    Iic_Scl = 1;
    Iic_Context.State = IIC_STATE_START_1;
}

static void Iic_HandleStart1(void)
{
    Iic_Sda = 0;
    Iic_Context.State = IIC_STATE_START_2;
}

static void Iic_HandleStart2(void)
{
    Iic_Scl = 0;
    Iic_Context.State = IIC_STATE_DONE;
}

static void Iic_HandleStop0(void)
{
    Iic_Sda = 0;
    Iic_Context.State = IIC_STATE_STOP_1;
}

static void Iic_HandleStop1(void)
{
    Iic_Scl = 1;
    Iic_Context.State = IIC_STATE_STOP_2;
}

static void Iic_HandleStop2(void)
{
    Iic_Sda = 1;
    Iic_Context.State = IIC_STATE_DONE;
}

static void Iic_HandleAck(void)
{
    Iic_Scl = 1;
    if((Iic_Sda == 0) || (Iic_Context.AckCount >= 250u))
    {
        Iic_Scl = 0;
        Iic_Context.State = IIC_STATE_DONE;
    }
    else
    {
        Iic_Context.AckCount++;
    }
}

static void Iic_HandleWriteLow(void)
{
    Iic_Scl = 0;
    if((Iic_Context.CurrentByte & 0x80u) != 0u)
    {
        Iic_Sda = 1;
    }
    else
    {
        Iic_Sda = 0;
    }
    Iic_Context.State = IIC_STATE_WRITE_HIGH;
}

static void Iic_HandleWriteHigh(void)
{
    Iic_Scl = 1;
    Iic_Context.CurrentByte = (uint8)(Iic_Context.CurrentByte << 1);
    Iic_Context.BitIndex++;
    if(Iic_Context.BitIndex >= 8u)
    {
        Iic_Scl = 0;
        Iic_Sda = 1;
        Iic_Context.State = IIC_STATE_DONE;
    }
    else
    {
        Iic_Context.State = IIC_STATE_WRITE_LOW;
    }
}

static void Iic_HandleReadLow(void)
{
    Iic_Scl = 0;
    Iic_Sda = 1;
    Iic_Context.State = IIC_STATE_READ_HIGH;
}

static void Iic_HandleReadHigh(void)
{
    Iic_Scl = 1;
    Iic_Context.ReadData = (uint8)((Iic_Context.ReadData << 1) | Iic_Sda);
    Iic_Context.BitIndex++;
    if(Iic_Context.BitIndex >= 8u)
    {
        Iic_Scl = 0;
        Iic_Context.State = IIC_STATE_DONE;
    }
    else
    {
        Iic_Context.State = IIC_STATE_READ_LOW;
    }
}

static void Iic_HandleNackLow(void)
{
    Iic_Scl = 0;
    Iic_Sda = 1;
    Iic_Context.State = IIC_STATE_NACK_HIGH;
}

static void Iic_HandleNackHigh(void)
{
    Iic_Scl = 1;
    Iic_Scl = 0;
    Iic_Context.State = IIC_STATE_DONE;
}

static void Iic_HandleInvalidState(void)
{
    /* 保持原行为：未知状态不做动作。 */
}

/* IIC运行期状态机：switch只负责分发，具体动作和迁移放在状态处理函数里。 */
void Iic_MainFunction(void)
{
    switch(Iic_Context.State)
    {
        case IIC_STATE_START_0:
            Iic_HandleStart0();
            break;
        case IIC_STATE_START_1:
            Iic_HandleStart1();
            break;
        case IIC_STATE_START_2:
            Iic_HandleStart2();
            break;
        case IIC_STATE_STOP_0:
            Iic_HandleStop0();
            break;
        case IIC_STATE_STOP_1:
            Iic_HandleStop1();
            break;
        case IIC_STATE_STOP_2:
            Iic_HandleStop2();
            break;
        case IIC_STATE_ACK:
            Iic_HandleAck();
            break;
        case IIC_STATE_WRITE_LOW:
            Iic_HandleWriteLow();
            break;
        case IIC_STATE_WRITE_HIGH:
            Iic_HandleWriteHigh();
            break;
        case IIC_STATE_READ_LOW:
            Iic_HandleReadLow();
            break;
        case IIC_STATE_READ_HIGH:
            Iic_HandleReadHigh();
            break;
        case IIC_STATE_NACK_LOW:
            Iic_HandleNackLow();
            break;
        case IIC_STATE_NACK_HIGH:
            Iic_HandleNackHigh();
            break;
        default:
            Iic_HandleInvalidState();
            break;
    }
}

/* IIC是否还在执行小操作。 */
boolean Iic_IsBusy(void)
{
    boolean isBusy;

    if((Iic_Context.State != IIC_STATE_IDLE) && (Iic_Context.State != IIC_STATE_DONE))
    {
        isBusy = TRUE;
    }
    else
    {
        isBusy = FALSE;
    }

    return isBusy;
}

/* IIC小操作是否已完成。读取后不会自动清除，由下一次StartOperation覆盖。 */
boolean Iic_IsDone(void)
{
    boolean isDone;

    if(Iic_Context.State == IIC_STATE_DONE)
    {
        isDone = TRUE;
    }
    else
    {
        isDone = FALSE;
    }

    return isDone;
}

/* 取得最近一次读字节操作的结果。 */
uint8 Iic_GetReadData(void)
{
    return Iic_Context.ReadData;
}
