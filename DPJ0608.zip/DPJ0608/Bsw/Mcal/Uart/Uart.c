/* UART底层驱动：配置8051串口和Timer1波特率，中断里收发字节。 */

#include "Uart.h"
#include "Uart_Cfg.h"
#include "SchM.h"

typedef struct
{
    uint8 RxBuffer[UART_RX_BUFFER_SIZE]; /* 接收环形缓冲：承接连续到来的命令帧。 */
    uint8 RxWriteIndex;
    uint8 RxReadIndex;
    boolean TxBusy;                      /* TRUE表示上一个字节还没发完。 */
} Uart_ContextType;

static volatile Uart_ContextType xdata Uart_Context;

/* 串口初始化：模式1接收，Timer1自动重装产生9600波特率，开启串口中断。 */
void Uart_Init(void)
{
    SCON = 0x50;                                   /* 模式1, REN=1(允许接收) */
    PCON = PCON & 0x7f;                            /* SMOD=0, 波特率不加倍 */
    ES   = 1;                                      /* 开串口中断 */
    TMOD = 0x20;                                   /* T1: 8位自动重装 */
    TH1  = TL1 = 256 - (UART_FOSC / 12 / 32 / UART_BAUD); /* 波特率 = 晶振/12/32/(256-TH1) */
    Uart_Context.RxWriteIndex = 0u;
    Uart_Context.RxReadIndex = 0u;
    Uart_Context.TxBusy = FALSE;
    TR1  = 1;                                      /* 启动定时器1 */
    EA   = 1;                                      /* 开总中断 */
}

/* 读取收到的一个字节：从环形缓冲弹出，空时返回0。 */
uint8 Uart_GetReceivedData(void)
{
    uint8 rxData;
    uint8 nextReadIndex;

    SchM_Enter_Uart_RxData();  /* 关中断 */
    if(Uart_Context.RxReadIndex != Uart_Context.RxWriteIndex)
    {
        rxData = Uart_Context.RxBuffer[Uart_Context.RxReadIndex];
        nextReadIndex = (uint8)(Uart_Context.RxReadIndex + 1u);
        if(nextReadIndex >= UART_RX_BUFFER_SIZE)
        {
            nextReadIndex = 0u;
        }
        Uart_Context.RxReadIndex = nextReadIndex;
    }
    else
    {
        rxData = 0u;
    }
    SchM_Exit_Uart_RxData();   /* 恢复中断 */

    return rxData;
}

/* 清除接收缓存：出现协议错误或需要重新同步时调用。 */
void Uart_ClearReceivedData(void)
{
    SchM_Enter_Uart_RxData();
    Uart_Context.RxReadIndex = Uart_Context.RxWriteIndex;
    SchM_Exit_Uart_RxData();
}

/* 查询接收缓冲区是否有待读字节。 */
boolean Uart_IsRxReady(void)
{
    boolean isReady;

    SchM_Enter_Uart_RxData();
    if(Uart_Context.RxReadIndex != Uart_Context.RxWriteIndex)
    {
        isReady = TRUE;
    }
    else
    {
        isReady = FALSE;
    }
    SchM_Exit_Uart_RxData();

    return isReady;
}

/* 发送一个字节：SBUF只能在空闲时写，发送完成由TI中断释放忙标志。 */
void Uart_SendByte(uint8 txData)
{
    if(Uart_Context.TxBusy == FALSE)
    {
        Uart_Context.TxBusy = TRUE;
        SBUF = txData;  /* 写发送缓冲 → 硬件自动开始发送 */
    }
}

/* 查询串口发送缓冲是否可写。 */
boolean Uart_IsTxReady(void)
{
    boolean isReady;

    if(Uart_Context.TxBusy == FALSE)
    {
        isReady = TRUE;
    }
    else
    {
        isReady = FALSE;
    }

    return isReady;
}

/* 串口中断：RI表示收到字节，TI表示发送完成。 */
void Uart_Isr() interrupt 4
{
    uint8 rxData;
    uint8 nextWriteIndex;

    if(RI == 1)
    {
        RI = 0;                    /* 清接收中断标志 */
        rxData = SBUF;             /* 从硬件缓冲读走数据 */
        nextWriteIndex = (uint8)(Uart_Context.RxWriteIndex + 1u);
        if(nextWriteIndex >= UART_RX_BUFFER_SIZE)
        {
            nextWriteIndex = 0u;
        }
        if(nextWriteIndex != Uart_Context.RxReadIndex)
        {
            Uart_Context.RxBuffer[Uart_Context.RxWriteIndex] = rxData;
            Uart_Context.RxWriteIndex = nextWriteIndex;
        }
        else
        {
            /* 缓冲区满时丢弃新字节，避免覆盖还没处理的数据。 */
        }
    }
    if(TI == 1)
    {
        TI = 0;                    /* 清发送中断标志 */
        Uart_Context.TxBusy = FALSE; /* 允许发送下一个字节 */
    }
}
