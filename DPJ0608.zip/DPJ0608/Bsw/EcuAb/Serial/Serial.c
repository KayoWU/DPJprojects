/* Serial抽象层：给UART加初始化保护，屏蔽底层寄存器细节。 */

#include "Serial.h"
#include "Uart.h"
#include "Det.h"

/* 初始化保护：未初始化就调用会记录Det错误。 */
static boolean Serial_IsInitialized = FALSE;

/* 串口抽象层初始化：向下调用Uart_Init，并记录Serial已可用。 */
void Serial_Init(void)
{
    Uart_Init();                      /* 配置UART硬件寄存器 */
    Serial_IsInitialized = TRUE;      /* 标记已初始化 */
}

/* 获取收到的串口字节：先检查初始化，再委托给MCAL/Uart。 */
uint8 Serial_GetReceivedData(void)
{
    uint8 rxData;

    if(Serial_IsInitialized == FALSE)
    {
        /* 还没初始化就调用 → 记录错误到Det，返回0 */
        (void)Det_ReportError(SERIAL_MODULE_ID, SERIAL_INSTANCE_ID,
                              SERIAL_GET_RECEIVED_DATA_API_ID, SERIAL_E_UNINIT);
        rxData = 0u;
    }
    else
    {
        rxData = Uart_GetReceivedData();    /* 委托给MCAL层读取 */
    }

    return rxData;
}

/* 清除串口接收缓存：命令消费完成后由上层调用。 */
void Serial_ClearReceivedData(void)
{
    if(Serial_IsInitialized == FALSE)
    {
        (void)Det_ReportError(SERIAL_MODULE_ID, SERIAL_INSTANCE_ID,
                              SERIAL_CLEAR_RECEIVED_DATA_API_ID, SERIAL_E_UNINIT);
    }
    else
    {
        Uart_ClearReceivedData();         /* 委托给MCAL层清除 */
    }
}

/* 查询串口接收缓冲区是否有数据。 */
boolean Serial_IsRxReady(void)
{
    boolean isReady;

    if(Serial_IsInitialized == FALSE)
    {
        (void)Det_ReportError(SERIAL_MODULE_ID, SERIAL_INSTANCE_ID,
                              SERIAL_IS_RX_READY_API_ID, SERIAL_E_UNINIT);
        isReady = FALSE;
    }
    else
    {
        isReady = Uart_IsRxReady();
    }

    return isReady;
}

/* 发送串口字节：抽象层只做保护检查，真正发送在Uart里完成。 */
void Serial_SendByte(uint8 txData)
{
    if(Serial_IsInitialized == FALSE)
    {
        (void)Det_ReportError(SERIAL_MODULE_ID, SERIAL_INSTANCE_ID,
                              SERIAL_SEND_BYTE_API_ID, SERIAL_E_UNINIT);
    }
    else
    {
        Uart_SendByte(txData);            /* 委托给MCAL层发送 */
    }
}

/* 查询串口是否可以发送下一个字节。 */
boolean Serial_IsTxReady(void)
{
    boolean isReady;

    if(Serial_IsInitialized == FALSE)
    {
        (void)Det_ReportError(SERIAL_MODULE_ID, SERIAL_INSTANCE_ID,
                              SERIAL_SEND_BYTE_API_ID, SERIAL_E_UNINIT);
        isReady = FALSE;
    }
    else
    {
        isReady = Uart_IsTxReady();
    }

    return isReady;
}
