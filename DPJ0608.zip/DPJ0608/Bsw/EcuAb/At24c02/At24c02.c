#include "At24c02.h"
#include "Iic.h"

#define AT24C02_BUFFER_SIZE       8u
#define AT24C02_STATE_IDLE        0u
#define AT24C02_STATE_START_REQ   1u
#define AT24C02_STATE_START_WAIT  2u
#define AT24C02_STATE_DEVW_REQ    3u
#define AT24C02_STATE_DEVW_WAIT   4u
#define AT24C02_STATE_ACK_REQ     5u
#define AT24C02_STATE_ACK_WAIT    6u
#define AT24C02_STATE_ADDR_REQ    7u
#define AT24C02_STATE_ADDR_WAIT   8u
#define AT24C02_STATE_DATA_REQ    9u
#define AT24C02_STATE_DATA_WAIT   10u
#define AT24C02_STATE_RSTART_REQ  11u
#define AT24C02_STATE_RSTART_WAIT 12u
#define AT24C02_STATE_DEVR_REQ    13u
#define AT24C02_STATE_DEVR_WAIT   14u
#define AT24C02_STATE_READ_REQ    15u
#define AT24C02_STATE_READ_WAIT   16u
#define AT24C02_STATE_STOP_REQ    17u
#define AT24C02_STATE_STOP_WAIT   18u
#define AT24C02_STATE_WRITE_WAIT  19u
#define AT24C02_STATE_DONE        20u
#define AT24C02_STATE_NACK_REQ    21u
#define AT24C02_STATE_NACK_WAIT   22u

#define AT24C02_JOB_NONE          0u
#define AT24C02_JOB_WRITE         1u
#define AT24C02_JOB_READ          2u

typedef uint8 At24c02_StateType;
typedef uint8 At24c02_JobType;

typedef struct
{
    At24c02_StateType State;
    At24c02_JobType Job;
    uint8 Address;
    uint8 Buffer[AT24C02_BUFFER_SIZE]; /* 异步读写共用：写前复制，读后上层取走。 */
    uint8 Length;
    uint8 Index;
    At24c02_StateType AfterAckState;
    uint16 WaitUntil;                  /* 写EEPROM后等待芯片内部自编程完成。 */
} At24c02_ContextType;

static At24c02_ContextType xdata At24c02_Context;

/* AT24C02初始化：先把软件IIC总线释放到空闲高电平。 */
void At24c02_Init(void)
{
    Iic_Init();
    At24c02_Context.State = AT24C02_STATE_IDLE;
    At24c02_Context.Job = AT24C02_JOB_NONE;
}

/* 异步写入：复制数据后立即返回，实际IIC动作由MainFunction推进。 */
Std_ReturnType At24c02_AsyncWrite(uint8 address, uint8 dataValue[], uint8 length)
{
    uint8 i;
    Std_ReturnType result;

    if((At24c02_IsBusy() == TRUE) || (length == 0u) || (length > AT24C02_BUFFER_SIZE))
    {
        result = E_NOT_OK;
    }
    else
    {
        for(i = 0u; i < length; i++)
        {
            At24c02_Context.Buffer[i] = dataValue[i];
        }
        At24c02_Context.Address = address;
        At24c02_Context.Length = length;
        At24c02_Context.Index = 0u;
        At24c02_Context.Job = AT24C02_JOB_WRITE;
        At24c02_Context.State = AT24C02_STATE_START_REQ;
        result = E_OK;
    }

    return result;
}

/* 异步读取：只发起任务，读取结果后续用At24c02_GetData取得。 */
Std_ReturnType At24c02_AsyncRead(uint8 address, uint8 length)
{
    Std_ReturnType result;

    if((At24c02_IsBusy() == TRUE) || (length == 0u) || (length > AT24C02_BUFFER_SIZE))
    {
        result = E_NOT_OK;
    }
    else
    {
        At24c02_Context.Address = address;
        At24c02_Context.Length = length;
        At24c02_Context.Index = 0u;
        At24c02_Context.Job = AT24C02_JOB_READ;
        At24c02_Context.State = AT24C02_STATE_START_REQ;
        result = E_OK;
    }

    return result;
}

static void At24c02_HandleStartReq(void)
{
    /* 先发IIC起始信号，后续所有步骤都等Iic_IsDone再继续。 */
    if(Iic_StartOperation(IIC_OPERATION_START, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_START_WAIT;
    }
}

static void At24c02_HandleStartWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.State = AT24C02_STATE_DEVW_REQ;
    }
}

static void At24c02_HandleDevwReq(void)
{
    /* 0xA0：器件地址 + 写方向，用于写数据，也用于读之前写入目标地址。 */
    if(Iic_StartOperation(IIC_OPERATION_WRITE_BYTE, 0xa0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_DEVW_WAIT;
    }
}

static void At24c02_HandleDevwWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.AfterAckState = AT24C02_STATE_ADDR_REQ;
        At24c02_Context.State = AT24C02_STATE_ACK_REQ;
    }
}

static void At24c02_HandleAckReq(void)
{
    if(Iic_StartOperation(IIC_OPERATION_WAIT_ACK, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_ACK_WAIT;
    }
}

static void At24c02_HandleAckWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        /* 不同阶段等ACK后要跳到不同状态，用AfterAckState保存下一步。 */
        At24c02_Context.State = At24c02_Context.AfterAckState;
    }
}

static void At24c02_HandleAddrReq(void)
{
    /* 每次操作一个字节，地址按Index递增。 */
    if(Iic_StartOperation(IIC_OPERATION_WRITE_BYTE, (uint8)(At24c02_Context.Address + At24c02_Context.Index)) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_ADDR_WAIT;
    }
}

static void At24c02_HandleAddrWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        if(At24c02_Context.Job == AT24C02_JOB_WRITE)
        {
            At24c02_Context.AfterAckState = AT24C02_STATE_DATA_REQ;
        }
        else
        {
            /* 随机读：先写目标地址，再重复起始切到读方向。 */
            At24c02_Context.AfterAckState = AT24C02_STATE_RSTART_REQ;
        }
        At24c02_Context.State = AT24C02_STATE_ACK_REQ;
    }
}

static void At24c02_HandleDataReq(void)
{
    if(Iic_StartOperation(IIC_OPERATION_WRITE_BYTE, At24c02_Context.Buffer[At24c02_Context.Index]) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_DATA_WAIT;
    }
}

static void At24c02_HandleDataWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.Index++;
        if(At24c02_Context.Index >= At24c02_Context.Length)
        {
            /* 写完最后一个字节后发STOP。 */
            At24c02_Context.AfterAckState = AT24C02_STATE_STOP_REQ;
        }
        else
        {
            At24c02_Context.AfterAckState = AT24C02_STATE_DATA_REQ;
        }
        At24c02_Context.State = AT24C02_STATE_ACK_REQ;
    }
}

static void At24c02_HandleRestartReq(void)
{
    if(Iic_StartOperation(IIC_OPERATION_START, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_RSTART_WAIT;
    }
}

static void At24c02_HandleRestartWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.State = AT24C02_STATE_DEVR_REQ;
    }
}

static void At24c02_HandleDevrReq(void)
{
    /* 0xA1：器件地址 + 读方向。 */
    if(Iic_StartOperation(IIC_OPERATION_WRITE_BYTE, 0xa1u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_DEVR_WAIT;
    }
}

static void At24c02_HandleDevrWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.AfterAckState = AT24C02_STATE_READ_REQ;
        At24c02_Context.State = AT24C02_STATE_ACK_REQ;
    }
}

static void At24c02_HandleReadReq(void)
{
    if(Iic_StartOperation(IIC_OPERATION_READ_BYTE, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_READ_WAIT;
    }
}

static void At24c02_HandleReadWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        /* 读回一个字节后暂存到缓冲区。 */
        At24c02_Context.Buffer[At24c02_Context.Index] = Iic_GetReadData();
        At24c02_Context.Index++;
        At24c02_Context.State = AT24C02_STATE_NACK_REQ;
    }
}

static void At24c02_HandleNackReq(void)
{
    /* 当前实现每次只读一个字节，读完用NACK结束本次读。 */
    if(Iic_StartOperation(IIC_OPERATION_SEND_NACK, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_NACK_WAIT;
    }
}

static void At24c02_HandleNackWait(void)
{
    if(Iic_IsDone() == TRUE)
    {
        At24c02_Context.State = AT24C02_STATE_STOP_REQ;
    }
}

static void At24c02_HandleStopReq(void)
{
    if(Iic_StartOperation(IIC_OPERATION_STOP, 0u) == E_OK)
    {
        At24c02_Context.State = AT24C02_STATE_STOP_WAIT;
    }
}

static void At24c02_HandleStopWait(uint16 tick)
{
    if(Iic_IsDone() == TRUE)
    {
        if(At24c02_Context.Job == AT24C02_JOB_WRITE)
        {
            At24c02_Context.WaitUntil = (uint16)(tick + 5u);
            At24c02_Context.State = AT24C02_STATE_WRITE_WAIT;
        }
        else if(At24c02_Context.Index < At24c02_Context.Length)
        {
            /* 多字节读用多次随机读完成，逻辑简单但不阻塞主循环。 */
            At24c02_Context.State = AT24C02_STATE_START_REQ;
        }
        else
        {
            At24c02_Context.State = AT24C02_STATE_DONE;
        }
    }
}

static void At24c02_HandleWriteWait(uint16 tick)
{
    if((sint16)(tick - At24c02_Context.WaitUntil) >= 0)
    {
        At24c02_Context.State = AT24C02_STATE_DONE;
    }
}

static void At24c02_HandleInvalidState(void)
{
    /* 保持原行为：未知状态不做动作。 */
}

/* AT24C02任务状态机：switch只负责分发，读写细节在各状态处理函数中完成。 */
void At24c02_MainFunction(uint16 tick)
{
    switch(At24c02_Context.State)
    {
        case AT24C02_STATE_START_REQ:
            At24c02_HandleStartReq();
            break;
        case AT24C02_STATE_START_WAIT:
            At24c02_HandleStartWait();
            break;
        case AT24C02_STATE_DEVW_REQ:
            At24c02_HandleDevwReq();
            break;
        case AT24C02_STATE_DEVW_WAIT:
            At24c02_HandleDevwWait();
            break;
        case AT24C02_STATE_ACK_REQ:
            At24c02_HandleAckReq();
            break;
        case AT24C02_STATE_ACK_WAIT:
            At24c02_HandleAckWait();
            break;
        case AT24C02_STATE_ADDR_REQ:
            At24c02_HandleAddrReq();
            break;
        case AT24C02_STATE_ADDR_WAIT:
            At24c02_HandleAddrWait();
            break;
        case AT24C02_STATE_DATA_REQ:
            At24c02_HandleDataReq();
            break;
        case AT24C02_STATE_DATA_WAIT:
            At24c02_HandleDataWait();
            break;
        case AT24C02_STATE_RSTART_REQ:
            At24c02_HandleRestartReq();
            break;
        case AT24C02_STATE_RSTART_WAIT:
            At24c02_HandleRestartWait();
            break;
        case AT24C02_STATE_DEVR_REQ:
            At24c02_HandleDevrReq();
            break;
        case AT24C02_STATE_DEVR_WAIT:
            At24c02_HandleDevrWait();
            break;
        case AT24C02_STATE_READ_REQ:
            At24c02_HandleReadReq();
            break;
        case AT24C02_STATE_READ_WAIT:
            At24c02_HandleReadWait();
            break;
        case AT24C02_STATE_NACK_REQ:
            At24c02_HandleNackReq();
            break;
        case AT24C02_STATE_NACK_WAIT:
            At24c02_HandleNackWait();
            break;
        case AT24C02_STATE_STOP_REQ:
            At24c02_HandleStopReq();
            break;
        case AT24C02_STATE_STOP_WAIT:
            At24c02_HandleStopWait(tick);
            break;
        case AT24C02_STATE_WRITE_WAIT:
            At24c02_HandleWriteWait(tick);
            break;
        default:
            At24c02_HandleInvalidState();
            break;
    }
}

/* AT24C02是否正在执行读写任务。 */
boolean At24c02_IsBusy(void)
{
    boolean isBusy;

    if((At24c02_Context.State != AT24C02_STATE_IDLE) && (At24c02_Context.State != AT24C02_STATE_DONE))
    {
        isBusy = TRUE;
    }
    else
    {
        isBusy = FALSE;
    }

    return isBusy;
}

/* 最近一次异步任务是否完成。 */
boolean At24c02_IsJobDone(void)
{
    boolean isDone;

    if(At24c02_Context.State == AT24C02_STATE_DONE)
    {
        isDone = TRUE;
    }
    else
    {
        isDone = FALSE;
    }

    return isDone;
}

/* 读取异步读任务缓冲区中的结果。 */
uint8 At24c02_GetData(uint8 index)
{
    uint8 dataValue;

    if(index >= AT24C02_BUFFER_SIZE)
    {
        dataValue = 0u;
    }
    else
    {
        dataValue = At24c02_Context.Buffer[index];
    }

    return dataValue;
}
