/* OS配置：定义任务数量和任务周期。 */

#ifndef OS_CFG_H
#define OS_CFG_H

#include "Os.h"

#define OS_TASK_COUNT              4u

#define OS_TASK_PERIOD_BSW_MS      1u
#define OS_TASK_PERIOD_FAST_MS     1u
#define OS_TASK_PERIOD_ADC_MS      10u
#define OS_TASK_PERIOD_SERIAL_MS   1u

extern Os_TaskConfigType code Os_TaskConfigTable[OS_TASK_COUNT];

#endif
