/* OS任务表：只描述“哪个任务多久执行一次”。 */

#include "Os_Cfg.h"
#include "App.h"

Os_TaskConfigType code Os_TaskConfigTable[OS_TASK_COUNT] =
{
    { App_BswTask,    OS_TASK_PERIOD_BSW_MS    },
    { App_FastTask,   OS_TASK_PERIOD_FAST_MS   },
    { App_AdcTask,    OS_TASK_PERIOD_ADC_MS    },
    { App_SerialTask, OS_TASK_PERIOD_SERIAL_MS }
};
