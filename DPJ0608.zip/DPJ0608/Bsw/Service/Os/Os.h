/* 轻量OS接口：基于Timer Tick的非抢占式任务调度。 */

#ifndef OS_H
#define OS_H

#include "Config.h"

#define OS_VENDOR_ID                 0u
#define OS_MODULE_ID                 20u
#define OS_SW_MAJOR_VERSION          1u
#define OS_SW_MINOR_VERSION          0u
#define OS_SW_PATCH_VERSION          0u

typedef void (*Os_TaskFuncType)(void);

typedef struct
{
    Os_TaskFuncType TaskFunc; /* 任务入口函数 */
    uint16 PeriodMs;          /* 周期，单位ms */
} Os_TaskConfigType;

void Os_Init(void);
void Os_MainFunction(void);

#endif
