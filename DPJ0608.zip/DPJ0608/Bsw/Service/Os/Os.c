/* 轻量OS实现：非抢占式轮询任务表，到期就调用任务函数。 */

#include "Os.h"
#include "Os_Cfg.h"
#include "Timer2.h"

static uint16 xdata Os_TaskNextRun[OS_TASK_COUNT];

void Os_Init(void)
{
    uint8 i;
    uint16 tick;

    tick = Timer2_GetTick();
    for(i = 0u; i < OS_TASK_COUNT; i++)
    {
        Os_TaskNextRun[i] = (uint16)(tick + Os_TaskConfigTable[i].PeriodMs);
    }
}

void Os_MainFunction(void)
{
    uint8 i;
    uint16 tick;

    tick = Timer2_GetTick();
    for(i = 0u; i < OS_TASK_COUNT; i++)
    {
        if((sint16)(tick - Os_TaskNextRun[i]) >= 0)
        {
            Os_TaskNextRun[i] = (uint16)(tick + Os_TaskConfigTable[i].PeriodMs);
            Os_TaskConfigTable[i].TaskFunc();
        }
    }
}
