/**
 * @file    Rte.h
 * @brief   Runtime Environment — application-facing service interface
 *
 * The RTE is the ONLY interface through which the Application layer
 * accesses hardware. App code never calls Serial/IoHwAb/Display directly.
 *
 * This implements the AUTOSAR principle of strict separation:
 *   App → Rte → EcuAb → Mcal → Hardware registers
 *
 * API grouping:
 *   Serial services:  receive, clear, byte transmit, transmit-ready
 *   Time services:    1ms system tick and runtime state-machine dispatch
 *   ADC services:     read raw ADC and convert to millivolts
 *   IR services:      receive decoded NEC remote key value
 *   LED services:     write 8-bit value to latched LED output
 *   LCD services:     asynchronous LCD1602 display requests
 *   EEPROM services:  asynchronous AT24C02 read/write requests
 *   SWC ports:        shared ADC data plus command/display/serial events
 */

#ifndef RTE_H
#define RTE_H

#include "Config.h"

/** Module identification (AUTOSAR-lite convention) */
#define RTE_VENDOR_ID                 0u
#define RTE_MODULE_ID                 2u
#define RTE_SW_MAJOR_VERSION          1u
#define RTE_SW_MINOR_VERSION          0u
#define RTE_SW_PATCH_VERSION          0u

#define RTE_DISPLAY_LINE2_NONE        0u
#define RTE_DISPLAY_LINE2_STATUS      1u
#define RTE_DISPLAY_LINE2_READ_ADC    2u
#define RTE_DISPLAY_LINE2_IR_KEY      3u

/**
 * @brief RTE 初始化 — 级联初始化所有ECU抽象层服务
 *
 * 初始化顺序：Serial → ADC → IR → LED → LCD1602 → AT24C02 → Timer2
 */
void  Rte_Init(void);
void  Rte_MainFunction(void);
uint16 Rte_GetSystemTick(void);

/** @name 串口服务（封装 EcuAb/Serial） */
uint8 Rte_ReadSerialData(void);         /* 读取串口收到的字节 */
void  Rte_ClearSerialData(void);        /* 清空接收缓存 */
void  Rte_SendSerialByte(uint8 txData); /* 发送一个字节 */
boolean Rte_IsSerialTxReady(void);      /* 串口发送是否空闲 */

/** @name ADC服务（封装 Mcal/Adc） */
uint8  Rte_ReadAdcValue(void);
uint16 Rte_AdcConvertToMv(uint8 adcValue);

/** @name 红外接收服务（封装 Mcal/IrSensor） */
boolean Rte_IrSensorIsKeyReady(void);
uint8 Rte_IrSensorGetKey(void);
void Rte_IrSensorClearKey(void);

/** @name 8位LED服务（封装 EcuAb/Led8） */
void Rte_Led8Write(uint8 value);

/** @name LCD1602服务（封装 EcuAb/Lcd1602） */
Std_ReturnType Rte_Lcd1602AsyncShowString(uint8 row, uint8 column, uint8 text[]);
boolean Rte_Lcd1602IsBusy(void);

/** @name AT24C02服务（封装 EcuAb/At24c02） */
Std_ReturnType Rte_At24c02AsyncWrite(uint8 address, uint8 dataValue[], uint8 length);
Std_ReturnType Rte_At24c02AsyncRead(uint8 address, uint8 length);
boolean Rte_At24c02IsBusy(void);
boolean Rte_At24c02IsJobDone(void);
uint8 Rte_At24c02GetData(uint8 index);

/** @name SWC数据端口：ADC采样值
 *  AdcSampler写入最新值，Storage等组件只通过RTE读取。
 */
void Rte_WriteAdcSample(uint8 adcRaw, uint16 adcMv);
uint8 Rte_ReadAdcRaw(void);
uint16 Rte_ReadAdcMv(void);

/** @name SWC事件端口：串口命令到存储组件
 *  Command发布请求，Storage消费请求，两个SWC不直接调用。
 */
void Rte_RequestAdcSave(void);
void Rte_RequestAdcRead(void);
boolean Rte_ConsumeAdcSaveRequest(void);
boolean Rte_ConsumeAdcReadRequest(void);

/** @name SWC事件端口：显示请求
 *  业务组件只提出“显示什么”，LCD Presenter负责格式化和刷新。
 */
void Rte_DisplayRequestAdcLine(uint8 adcRaw, uint16 adcMv);
boolean Rte_DisplayConsumeAdcLine(uint8 *adcRaw, uint16 *adcMv);
void Rte_DisplayRequestStatusLine(uint8 text[]);
void Rte_DisplayRequestReadLine(uint8 adcRaw, uint16 adcMv);
void Rte_DisplayRequestIrLine(uint8 keyValue);
boolean Rte_DisplayConsumeLine2(uint8 *lineType,
                                uint8 *adcRaw,
                                uint16 *adcMv,
                                uint8 *keyValue,
                                uint8 text[]);

/** @name SWC事件端口：串口文本回传
 *  Storage发布读回数据，SerialTx按串口空闲状态逐字节发送。
 */
void Rte_RequestSerialReadMessage(uint8 adcRaw, uint16 adcMv);
boolean Rte_ConsumeSerialReadMessage(uint8 *adcRaw, uint16 *adcMv);

#endif
