#include "Swc_IrHandler.h"
#include "Rte.h"

void Swc_IrHandler_Init(void)
{
}

/* 红外业务：收到按键后，同步更新LED和LCD显示请求。 */
void Swc_IrHandler_MainFunction(void)
{
    uint8 keyValue;

    if(Rte_IrSensorIsKeyReady() == TRUE)
    {
        keyValue = Rte_IrSensorGetKey();
        Rte_IrSensorClearKey();
        Rte_Led8Write(keyValue);
        Rte_DisplayRequestIrLine(keyValue);
    }
}
