/**
 * @file    App.c
 * @brief   Application scheduler for AUTOSAR-lite SWCs
 *
 * App层只负责初始化和周期调度；具体业务拆到各个SWC中。
 */

#include "App.h"
#include "Rte.h"
#include "Swc_AdcSampler.h"
#include "Swc_Command.h"
#include "Swc_Storage.h"
#include "Swc_IrHandler.h"
#include "Swc_LcdPresenter.h"
#include "Swc_SerialTx.h"

static boolean App_IsInitialized = FALSE;

static void App_Init(void)
{
    Swc_AdcSampler_Init();
    Swc_Command_Init();
    Swc_Storage_Init();
    Swc_IrHandler_Init();
    Swc_LcdPresenter_Init();
    Swc_SerialTx_Init();
    App_IsInitialized = TRUE;
}

/* 应用层周期任务：先推进底层状态机，再调度各个SWC。 */
void App_MainFunction(void)
{
    uint16 tick;

    Rte_MainFunction();
    tick = Rte_GetSystemTick();

    if(App_IsInitialized == FALSE)
    {
        App_Init();
    }

    Swc_AdcSampler_MainFunction(tick);
    Swc_Command_MainFunction();
    Swc_Storage_MainFunction();
    Swc_IrHandler_MainFunction();
    Swc_LcdPresenter_MainFunction();
    Swc_SerialTx_MainFunction();
}
