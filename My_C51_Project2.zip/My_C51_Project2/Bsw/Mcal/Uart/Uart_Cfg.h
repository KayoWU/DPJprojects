/* UART配置：晶振频率和目标波特率，Uart_Init()用它们计算Timer1重装值。 */

#ifndef UART_CFG_H
#define UART_CFG_H

#define UART_FOSC 11059200L   /* 系统晶振频率，单位Hz */
#define UART_BAUD 9600u       /* 目标串口波特率 */

/* 接收环形缓冲区大小：用于保存连续到来的命令帧字节。 */
#define UART_RX_BUFFER_SIZE 8u

#endif
